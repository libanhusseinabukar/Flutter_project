package com.example.flutter_newsapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
